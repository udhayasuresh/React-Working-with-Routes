import React from 'react';
import Services from '../common/Services'
//import axios from 'axios'



class Header extends React.Component{
    constructor(props){
        super(props);
        this.state ={
            error: null,
            isLoaded: false,
            persons: []
        }
    }
    componentDidMount() {
        Services.getApi(`users`)
          .then(res => {
            const persons = res.data;
            this.setState({ persons });
            console.log(persons)
          })
      }
  
      
    render(){
      
        let memberList = this.state.persons;
        console.log(memberList)

   
      return (
        <div>
                <div>
                  <table>
                    <thead>
                      <tr>
                        <th className="h-60">Account Name</th>
                     
                        <th className="h-60">Account code</th>
                        <th className="h-60">Member software</th>
                        
                        
                      </tr>
                    </thead>
                    <tbody>  
                        {
                            memberList && memberList.length ?
                            this.state.persons.map( (obj, indx) => (
                                <OrgMemberdetailCard key={indx} obj={obj} />
                              ) )
                            :null
                        }
                    

                     
                       
                    </tbody>
                  </table>	
                </div>	
        </div>
      );
    }
  }

export default Header

function OrgMemberdetailCard(props){
    //const {obj}=props;
      console.log(props)
      const {obj} =props;
      console.log(obj)
   
    return(
        <>
        <tr>
            <td>{obj.name}</td>
            <td>{obj.username}</td>
            <td>{obj.email}</td>          
        </tr>
       
  
        </>
    );
  }